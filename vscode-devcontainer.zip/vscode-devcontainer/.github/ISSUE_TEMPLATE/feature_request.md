---
name: Feature request
about: Suggest an idea for this project

---

<!--  🚨 Please only include feature requests related to Dev Container Definitions here. 🚨 Other locations:
        VS Code Remote Development: http://github.com/Microsoft/vscode-remote-release 
        VS Code OSS: http://github.com/Microsoft/vscode
        GitHub Codespaces: https://github.com/github/feedback/discussions/categories/codespaces-feedback
-->

<!-- Describe the feature request -->

Relates to: <Codespaces | Remote - Containers | Both>
