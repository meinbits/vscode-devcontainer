---
name: Question
about: Please ask questions on https://stackoverflow.com/questions/tagged/visual-studio-code or https://github.com/github/feedback/discussions/categories/codespaces-feedback


---

🚨 The issue tracker is not for questions 🚨

If you have a question, please ask it on https://stackoverflow.com/questions/tagged/visual-studio-code or for GitHub Codespaces https://github.com/github/feedback/discussions/categories/codespaces-feedback
