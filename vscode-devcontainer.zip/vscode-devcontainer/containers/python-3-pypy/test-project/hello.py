print('Hello, remote world!')
